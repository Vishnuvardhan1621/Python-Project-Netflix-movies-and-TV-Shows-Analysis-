import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("netflix_titles.csv")

# Remove missing countries
country_df = df.dropna(subset=["country"])

# Split multiple countries and count them
countries = country_df["country"].str.split(", ").explode()

# Get top 10 countries
top_countries = countries.value_counts().head(10)

print("Top 10 Countries:")
print(top_countries)

# Plot
plt.figure(figsize=(12, 6))

sns.barplot(
    x=top_countries.values,
    y=top_countries.index
)

plt.title("Top 10 Countries by Netflix Content")
plt.xlabel("Number of Titles")
plt.ylabel("Country")

plt.show()