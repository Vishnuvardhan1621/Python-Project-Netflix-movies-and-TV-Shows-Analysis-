import pandas as pd
import mysql.connector
import matplotlib.pyplot as plt
import seaborn as sns

# Connect to MySQL
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

print("MySQL connected successfully!")

# SQL query
query = """
SELECT type, COUNT(*) AS total
FROM netflix_titles
GROUP BY type
"""

# Get result from MySQL into Pandas
df = pd.read_sql(query, connection)

print("\nMovies vs TV Shows:")
print(df)

# Create chart
sns.barplot(data=df, x="type", y="total")

plt.title("Movies vs TV Shows on Netflix")
plt.xlabel("Content Type")
plt.ylabel("Number of Titles")

plt.show()

# Close connection
connection.close()

print("\nMySQL connection closed!")