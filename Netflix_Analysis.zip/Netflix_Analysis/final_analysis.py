import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import mysql.connector


# ==============================
# 1. Load Netflix Dataset
# ==============================

df = pd.read_csv("netflix_titles.csv")

print("Dataset Loaded Successfully!")
print("Dataset Shape:", df.shape)


# ==============================
# 2. MySQL Connection
# ==============================

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

print("MySQL Connection Successful!")


# ==============================
# 3. Movies vs TV Shows
# ==============================

query = """
SELECT
    type,
    COUNT(*) AS total
FROM netflix_titles
GROUP BY type;
"""

result = pd.read_sql(query, connection)

print("\nMovies vs TV Shows:")
print(result)


# ==============================
# 4. Movies vs TV Shows Chart
# ==============================

plt.figure(figsize=(8, 5))

sns.barplot(
    data=result,
    x="type",
    y="total"
)

plt.title("Movies vs TV Shows")
plt.xlabel("Content Type")
plt.ylabel("Number of Titles")

plt.show()


# ==============================
# 5. Close MySQL Connection
# ==============================

# ==============================
# 6. Top 10 Genres
# ==============================

genre_df = df.dropna(subset=["listed_in"]).copy()

genres = genre_df["listed_in"].str.split(", ").explode()

top_genres = genres.value_counts().head(10)

print("\nTop 10 Genres:")
print(top_genres)


# ==============================
# 7. Top 10 Genres Chart
# ==============================

plt.figure(figsize=(12, 6))

sns.barplot(
    x=top_genres.values,
    y=top_genres.index
)

plt.title("Top 10 Netflix Genres")
plt.xlabel("Number of Titles")
plt.ylabel("Genre")

plt.show()

# ==============================
# 8. Content by Release Year
# ==============================

release_year = (
    df["release_year"]
    .value_counts()
    .sort_index()
)

print("\nContent by Release Year:")
print(release_year)


# ==============================
# 9. Release Year Trend Chart
# ==============================

plt.figure(figsize=(12, 6))

sns.lineplot(
    x=release_year.index,
    y=release_year.values
)

plt.title("Netflix Content by Release Year")
plt.xlabel("Release Year")
plt.ylabel("Number of Titles")

plt.show()

# ==============================
# 10. Top 10 Countries
# ==============================

country_df = df.dropna(subset=["country"]).copy()

countries = country_df["country"].str.split(", ").explode()

top_countries = countries.value_counts().head(10)

print("\nTop 10 Countries:")
print(top_countries)


# ==============================
# 11. Top 10 Countries Chart
# ==============================

plt.figure(figsize=(12, 6))

sns.barplot(
    x=top_countries.values,
    y=top_countries.index
)

plt.title("Top 10 Countries by Netflix Content")
plt.xlabel("Number of Titles")
plt.ylabel("Country")

plt.show()

# ==============================
# 12. Duration Analysis
# ==============================

duration_df = df.dropna(subset=["duration"]).copy()

duration_count = duration_df["duration"].value_counts().head(10)

print("\nTop 10 Duration Values:")
print(duration_count)


# ==============================
# 13. Duration Chart
# ==============================

plt.figure(figsize=(12, 6))

sns.barplot(
    x=duration_count.values,
    y=duration_count.index
)

plt.title("Top 10 Netflix Content Durations")
plt.xlabel("Number of Titles")
plt.ylabel("Duration")

plt.show()

# ==============================
# 14. Movies vs TV Shows Percentage
# ==============================

query = """
SELECT
    type,
    COUNT(*) AS total,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM netflix_titles),
        2
    ) AS percentage
FROM netflix_titles
GROUP BY type;
"""

percentage_result = pd.read_sql(query, connection)

print("\nMovies vs TV Shows Percentage:")
print(percentage_result)


# ==============================
# 15. Percentage Chart
# ==============================

plt.figure(figsize=(8, 5))

sns.barplot(
    data=percentage_result,
    x="type",
    y="percentage"
)

plt.title("Movies vs TV Shows Percentage")
plt.xlabel("Content Type")
plt.ylabel("Percentage (%)")

plt.show()

# ==============================
# 16. Content Released From 2020 Onwards
# ==============================

query = """
SELECT
    type,
    COUNT(*) AS total
FROM netflix_titles
WHERE release_year >= 2020
GROUP BY type
ORDER BY total DESC;
"""

recent_content = pd.read_sql(query, connection)

print("\nContent Released From 2020 Onwards:")
print(recent_content)


# ==============================
# 17. Recent Content Chart
# ==============================

plt.figure(figsize=(8, 5))

sns.barplot(
    data=recent_content,
    x="type",
    y="total"
)

plt.title("Netflix Content Released From 2020 Onwards")
plt.xlabel("Content Type")
plt.ylabel("Number of Titles")

plt.show()

# ==============================
# 18. Average Release Year by Type
# ==============================

query = """
SELECT
    type,
    ROUND(AVG(release_year), 2) AS average_release_year
FROM netflix_titles
GROUP BY type;
"""

average_year = pd.read_sql(query, connection)

print("\nAverage Release Year by Type:")
print(average_year)


# ==============================
# 19. Average Release Year Chart
# ==============================

plt.figure(figsize=(8, 5))

sns.barplot(
    data=average_year,
    x="type",
    y="average_release_year"
)

plt.title("Average Release Year by Content Type")
plt.xlabel("Content Type")
plt.ylabel("Average Release Year")

plt.show()

connection.close()

print("\nMySQL Connection Closed!")
print("Netflix Analysis Project Completed Successfully!")