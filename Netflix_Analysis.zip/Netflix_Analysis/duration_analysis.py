import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("netflix_titles.csv")

# Remove missing duration values
duration_df = df.dropna(subset=["duration"])

# Count duration
duration_count = duration_df["duration"].value_counts().head(10)

print("Top 10 Duration Values:")
print(duration_count)

# Plot
plt.figure(figsize=(12, 6))

sns.barplot(
    x=duration_count.index,
    y=duration_count.values
)

plt.title("Top 10 Netflix Content Durations")
plt.xlabel("Duration")
plt.ylabel("Number of Titles")
plt.xticks(rotation=45)

plt.show()