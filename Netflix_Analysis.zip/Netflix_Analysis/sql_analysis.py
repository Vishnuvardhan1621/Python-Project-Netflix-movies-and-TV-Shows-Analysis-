import mysql.connector
import pandas as pd


# ==============================
# 1. MySQL Connection
# ==============================

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

print("MySQL connection successful!")


# ==============================
# 2. Movies vs TV Shows
# ==============================

query = """
SELECT type, COUNT(*) AS total
FROM netflix_titles
GROUP BY type;
"""

result = pd.read_sql(query, connection)

print("\nMovies vs TV Shows:")
print(result)


# ==============================
# 3. Top 10 Ratings
# ==============================

query = """
SELECT rating, COUNT(*) AS total
FROM netflix_titles
GROUP BY rating
ORDER BY total DESC
LIMIT 10;
"""

result = pd.read_sql(query, connection)

print("\nTop 10 Ratings:")
print(result)


# ==============================
# 4. Top 10 Release Years
# ==============================

query = """
SELECT release_year, COUNT(*) AS total
FROM netflix_titles
GROUP BY release_year
ORDER BY total DESC
LIMIT 10;
"""

result = pd.read_sql(query, connection)

print("\nTop 10 Release Years:")
print(result)


# ==============================
# 5. Top 10 Countries
# ==============================

query = """
SELECT country, COUNT(*) AS total
FROM netflix_titles
WHERE country IS NOT NULL
GROUP BY country
ORDER BY total DESC
LIMIT 10;
"""

result = pd.read_sql(query, connection)

print("\nTop 10 Countries:")
print(result)


# ==============================
# 6. Movies vs TV Shows Percentage
# ==============================

query = """
SELECT
    type,
    COUNT(*) AS total,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM netflix_titles),
        2
    ) AS percentage
FROM netflix_titles
GROUP BY type;
"""

result = pd.read_sql(query, connection)

print("\nMovies vs TV Shows Percentage:")
print(result)


# ==============================
# 7. Rating-wise Movies vs TV Shows
# ==============================

query = """
SELECT
    rating,
    type,
    COUNT(*) AS total
FROM netflix_titles
WHERE rating IN (
    'G',
    'NC-17',
    'NR',
    'PG',
    'PG-13',
    'R',
    'TV-14',
    'TV-G',
    'TV-MA',
    'TV-PG',
    'TV-Y',
    'TV-Y7',
    'TV-Y7-FV'
)
GROUP BY rating, type
ORDER BY rating, total DESC;
"""

result = pd.read_sql(query, connection)

print("\nRating-wise Movies vs TV Shows:")
print(result)


# ==============================
# 8. Popular Genres
# ==============================

query = """
SELECT
    'Dramas' AS genre,
    COUNT(*) AS total
FROM netflix_titles
WHERE listed_in LIKE '%Dramas%'

UNION ALL

SELECT
    'Comedies' AS genre,
    COUNT(*) AS total
FROM netflix_titles
WHERE listed_in LIKE '%Comedies%'

UNION ALL

SELECT
    'Action' AS genre,
    COUNT(*) AS total
FROM netflix_titles
WHERE listed_in LIKE '%Action%'

UNION ALL

SELECT
    'Documentaries' AS genre,
    COUNT(*) AS total
FROM netflix_titles
WHERE listed_in LIKE '%Documentaries%'

UNION ALL

SELECT
    'International Movies' AS genre,
    COUNT(*) AS total
FROM netflix_titles
WHERE listed_in LIKE '%International Movies%'

ORDER BY total DESC;
"""

result = pd.read_sql(query, connection)

print("\nPopular Genres:")
print(result)


# ==============================
# 9. Average Release Year by Type
# ==============================

query = """
SELECT
    type,
    ROUND(AVG(release_year), 2) AS average_release_year
FROM netflix_titles
GROUP BY type;
"""

result = pd.read_sql(query, connection)

print("\nAverage Release Year by Type:")
print(result)


# ==============================
# 10. Content Released From 2020 Onwards
# ==============================

query = """
SELECT
    type,
    COUNT(*) AS total
FROM netflix_titles
WHERE release_year >= 2020
GROUP BY type
ORDER BY total DESC;
"""

result = pd.read_sql(query, connection)

print("\nContent Released From 2020 Onwards:")
print(result)


# ==============================
# 11. Top 10 Duration Values
# ==============================

query = """
SELECT
    duration,
    COUNT(*) AS total
FROM netflix_titles
WHERE duration IS NOT NULL
GROUP BY duration
ORDER BY total DESC
LIMIT 10;
"""

result = pd.read_sql(query, connection)

print("\nTop 10 Duration Values:")
print(result)


# ==============================
# 12. Close Connection
# ==============================

connection.close()

print("\nMySQL connection closed.")
print("SQL Analysis Completed Successfully!")