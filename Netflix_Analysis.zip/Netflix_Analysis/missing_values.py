import pandas as pd
import mysql.connector

# Connect to MySQL
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

print("MySQL connected successfully!")

# Read data from MySQL
query = "SELECT * FROM netflix_titles"

df = pd.read_sql(query, connection)

# Check missing values
print("\nMissing values in each column:")
print(df.isnull().sum())

# Check missing values percentage
print("\nMissing values percentage:")
print((df.isnull().sum() / len(df)) * 100)

# Close connection
connection.close()

print("\nMySQL connection closed!")