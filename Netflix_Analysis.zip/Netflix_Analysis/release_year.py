import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("netflix_titles.csv")

# Count content by release year
release_year = df["release_year"].value_counts().sort_index()

print("Netflix Content by Release Year:")
print(release_year)

# Plot
plt.figure(figsize=(12, 6))

sns.lineplot(
    x=release_year.index,
    y=release_year.values
)

plt.title("Netflix Content by Release Year")
plt.xlabel("Release Year")
plt.ylabel("Number of Titles")

plt.show()