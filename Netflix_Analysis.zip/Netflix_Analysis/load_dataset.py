import pandas as pd
import os

base_path = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(base_path, "netflix_titles.csv")

df = pd.read_csv(csv_path)

print(df.head())
print("Dataset loaded successfully!")
print("Rows and Columns:", df.shape)