import pandas as pd
import mysql.connector
import os


# 1. Load CSV
base_path = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(base_path, "netflix_titles.csv")

df = pd.read_csv(csv_path)

print("CSV loaded successfully!")
print("Total rows:", len(df))


# 2. Convert NaN values to None
df = df.astype(object).where(pd.notnull(df), None)


# 3. Connect to MySQL
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

cursor = connection.cursor()

print("MySQL connected successfully!")


# 4. INSERT query
query = """
INSERT INTO netflix_titles
(
    show_id,
    type,
    title,
    director,
    cast,
    country,
    date_added,
    release_year,
    rating,
    duration,
    listed_in,
    description
)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
"""


# 5. Insert data
for _, row in df.iterrows():

    values = (
        row["show_id"],
        row["type"],
        row["title"],
        row["director"],
        row["cast"],
        row["country"],
        row["date_added"],
        row["release_year"],
        row["rating"],
        row["duration"],
        row["listed_in"],
        row["description"]
    )

    cursor.execute(query, values)


# 6. Save changes
connection.commit()

print("Data inserted into MySQL successfully!")


# 7. Close connection
cursor.close()
connection.close()

print("MySQL connection closed!")