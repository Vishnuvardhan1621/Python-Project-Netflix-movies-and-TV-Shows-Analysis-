import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

if connection.is_connected():
    print("MySQL Connected Successfully!")

connection.close()
print("Connection Closed!")