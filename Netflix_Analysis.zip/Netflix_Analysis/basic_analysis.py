import pandas as pd
import mysql.connector


# Connect to MySQL
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

print("MySQL connected successfully!")


# Read data from MySQL
query = "SELECT * FROM netflix_titles"

df = pd.read_sql(query, connection)


# Basic analysis
print("\nFirst 5 records:")
print(df.head())


print("\nDataset shape:")
print(df.shape)


print("\nColumn names:")
print(df.columns.tolist())


print("\nDataset information:")
print(df.info())


# Close connection
connection.close()

print("\nMySQL connection closed!")