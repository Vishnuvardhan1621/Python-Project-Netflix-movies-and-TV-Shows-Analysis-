import pandas as pd
import mysql.connector
import matplotlib.pyplot as plt
import seaborn as sns

# Connect to MySQL
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

print("MySQL connected successfully!")

# Get country data from MySQL
query = """
SELECT country
FROM netflix_titles
WHERE country IS NOT NULL
"""

df = pd.read_sql(query, connection)

# Split multiple countries
countries = df["country"].str.split(", ").explode()

# Count countries
top_countries = countries.value_counts().head(10)

print("\nTop 10 Countries:")
print(top_countries)

# Create chart
top_countries.plot(kind="bar")

plt.title("Top 10 Countries by Netflix Content")
plt.xlabel("Country")
plt.ylabel("Number of Titles")
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# Close connection
connection.close()

print("\nMySQL connection closed!")