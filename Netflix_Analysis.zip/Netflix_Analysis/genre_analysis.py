import pandas as pd
import mysql.connector
import matplotlib.pyplot as plt

# Connect to MySQL
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="netflix_db"
)

print("MySQL connected successfully!")

# Get genre data from MySQL
query = """
SELECT listed_in
FROM netflix_titles
WHERE listed_in IS NOT NULL
"""

df = pd.read_sql(query, connection)

# Split multiple genres
genres = df["listed_in"].str.split(", ").explode()

# Count genres
top_genres = genres.value_counts().head(10)

print("\nTop 10 Genres:")
print(top_genres)

# Create chart
top_genres.plot(kind="bar")

plt.title("Top 10 Netflix Genres")
plt.xlabel("Genre")
plt.ylabel("Number of Titles")
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# Close connection
connection.close()

print("\nMySQL connection closed!")